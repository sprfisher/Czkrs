import { Redirect } from 'expo-router';

const Home = () => {
  return <Redirect href={'login'}></Redirect>;
};

export default Home;
