-- AlterEnum
ALTER TYPE "GameStatus" ADD VALUE 'PLAYER_EXIT';
