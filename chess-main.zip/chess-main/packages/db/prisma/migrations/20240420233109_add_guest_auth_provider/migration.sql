-- AlterEnum
ALTER TYPE "AuthProvider" ADD VALUE 'GUEST';
