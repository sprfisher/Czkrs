-- AlterTable
ALTER TABLE "Move" ADD COLUMN     "san" TEXT;
