
-- AlterTable
ALTER TABLE "Move" RENAME COLUMN "endFen" to "after";
ALTER TABLE "Move" RENAME COLUMN "startFen" to "before";