-- AlterEnum
ALTER TYPE "GameStatus" ADD VALUE 'TIME_UP';
